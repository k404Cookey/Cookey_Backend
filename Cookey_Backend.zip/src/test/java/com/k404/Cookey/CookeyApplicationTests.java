package com.k404.Cookey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
