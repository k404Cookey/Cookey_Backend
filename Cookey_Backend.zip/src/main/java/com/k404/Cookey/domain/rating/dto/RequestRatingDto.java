package com.k404.Cookey.domain.rating.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RequestRatingDto {
    private double star;
}
