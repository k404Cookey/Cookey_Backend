package com.k404.Cookey.domain.common;

public enum YesOrNo {
	Y, N
}
