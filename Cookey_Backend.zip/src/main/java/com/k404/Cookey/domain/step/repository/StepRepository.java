package com.k404.Cookey.domain.step.repository;

import com.k404.Cookey.domain.step.entity.Step;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StepRepository extends JpaRepository<Step, Long> {
}
