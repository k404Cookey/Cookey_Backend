package com.k404.Cookey.domain.recipe.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ThemeDto {
    private Long id;
    private String name;

}
